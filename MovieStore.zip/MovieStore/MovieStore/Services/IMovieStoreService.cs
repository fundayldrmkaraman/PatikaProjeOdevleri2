﻿using MovieStore.DTO_s;

namespace MovieStore.Services
{
    public interface IMovieStoreService
    { 
        FilmDTO AddFilm(FilmDTO filmDTO);
        void UpdateFilm(FilmDTO filmDTO);
        void DeleteFilm(int filmId);
        List<FilmDTO> GetFilms();

        YonetmenDTO AddYonetmen(YonetmenDTO yonetmenDTO);
        void UpdateYonetmen(YonetmenDTO yonetmenDTO);
        void DeleteYonetmen(int yonetmenId);
        List<YonetmenDTO> GetYonetmenler();

        OyuncuDTO AddOyuncu(OyuncuDTO oyuncuDTO);
        void UpdateOyuncu(OyuncuDTO oyuncuDTO);
        void DeleteOyuncu(int oyuncuId);
        List<OyuncuDTO> GetOyuncular();

        CustomerDTO AddCustomer(CustomerDTO customerDTO);
        void DeleteCustomer(int customerId);
        List<CustomerDTO> GetCustomers();

        SiparisDTO SatinAl(CustomerDTO customerDTO, FilmDTO filmDTO);
        List<SiparisDTO> GetSiparislerByCustomerId(int customerId);
    }
}
