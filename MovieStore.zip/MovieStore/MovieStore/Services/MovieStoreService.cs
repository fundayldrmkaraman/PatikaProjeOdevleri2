﻿using MovieStore.DTO_s;
using MovieStore.Models;
using MovieStore.MovieStoreDbContext;

namespace MovieStore.Services
{
    public class MovieStoreService:IMovieStoreService
    {
        private readonly MovieStoreDbContext _dbContext;

        public MovieStoreService(MovieStoreDbContext dbContext)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        }

        // Film işlemleri
        public FilmDTO AddFilm(FilmDTO filmDTO)
        {
            var film = new Film
            {
                // DTO'dan gelen veriyi model sınıfına dönüştür
            };

            _dbContext.Films.Add(film);
            _dbContext.SaveChanges();

            return new FilmDTO
            {
                FilmAdi = filmDTO.FilmAdi,
                FilmYili = filmDTO.FilmYili,
                FilmTuru = filmDTO.FilmTuru
            };
        }

        public void UpdateFilm(FilmDTO filmDTO)
        {
            var existingFilm = _dbContext.Films.Find(filmDTO.Id);

            if (existingFilm != null)
            {
                existingFilm.FilmAdi = filmDTO.FilmAdi;
                existingFilm.FilmYili = filmDTO.FilmYili;
                existingFilm.FilmTuru = filmDTO.FilmTuru;

                _dbContext.SaveChanges();
            }
        }

        public void DeleteFilm(int filmId)
        {
            var filmToDelete = _dbContext.Films.Find(filmId);

            if (filmToDelete != null)
            {
                _dbContext.Films.Remove(filmToDelete);
                _dbContext.SaveChanges();
            }
        }

        public List<FilmDTO> GetFilms()
        {
            return _dbContext.Films
                .Select(f => new FilmDTO
                {
                    FilmAdi = f.FilmAdi,
                    FilmTuru=f.FilmTuru,
                })
                .ToList();
        }

        public YonetmenDTO AddYonetmen(YonetmenDTO yonetmenDTO)
        {
            throw new NotImplementedException();
        }

        public void UpdateYonetmen(YonetmenDTO yonetmenDTO)
        {
            throw new NotImplementedException();
        }

        public void DeleteYonetmen(int yonetmenId)
        {
            throw new NotImplementedException();
        }

        public List<YonetmenDTO> GetYonetmenler()
        {
            throw new NotImplementedException();
        }

        public OyuncuDTO AddOyuncu(OyuncuDTO oyuncuDTO)
        {
            throw new NotImplementedException();
        }

        public void UpdateOyuncu(OyuncuDTO oyuncuDTO)
        {
            throw new NotImplementedException();
        }

        public void DeleteOyuncu(int oyuncuId)
        {
            throw new NotImplementedException();
        }

        public List<OyuncuDTO> GetOyuncular()
        {
            throw new NotImplementedException();
        }

        public CustomerDTO AddCustomer(CustomerDTO customerDTO)
        {
            throw new NotImplementedException();
        }

        public void DeleteCustomer(int customerId)
        {
            throw new NotImplementedException();
        }

        public List<CustomerDTO> GetCustomers()
        {
            throw new NotImplementedException();
        }

        public SiparisDTO SatinAl(CustomerDTO customerDTO, FilmDTO filmDTO)
        {
            throw new NotImplementedException();
        }

        public List<SiparisDTO> GetSiparislerByCustomerId(int customerId)
        {
            throw new NotImplementedException();
        }
    }
}
