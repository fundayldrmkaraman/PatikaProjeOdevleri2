﻿namespace MovieStore.Models
{
    public class Film
    {
        public int Id { get; set; }
        public string FilmAdi { get; set; }
        public int FilmYili { get; set; }
        public string FilmTuru { get; set; }
        public Yonetmen Yonetmen { get; set; }
        public List<Oyuncu> Oyuncular { get; set; }
        public decimal Fiyat { get; set; }
        public string Kategori { get; set; }
    }
}
