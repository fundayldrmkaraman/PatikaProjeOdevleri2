﻿namespace MovieStore.Models
{
    public class Siparis
    {
        public int Id { get; set; }
        public Customer Musteri { get; set; }
        public Film SatinAlinanFilm { get; set; }
        public decimal Fiyat { get; set; }
        public DateTime SatinAlmaTarihi { get; set; }
    }
}
