﻿namespace MovieStore.Models
{
    public class Oyuncu
    {
        public int Id { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public List<Film> OynadigiFilmler { get; set; }
        public string Kategori { get; set; }
    }
}
