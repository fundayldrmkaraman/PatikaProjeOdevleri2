﻿namespace MovieStore.Models
{
    public class Yonetmen
    {
        public int Id { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public List<Film> YonetilenFilmler { get; set; }
        public string Kategori { get; set; }
    }
}
