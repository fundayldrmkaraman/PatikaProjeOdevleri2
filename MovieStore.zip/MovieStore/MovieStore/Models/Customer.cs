﻿namespace MovieStore.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public List<Film> SatinAldigiFilmler { get; set; }
        public List<string> FavoriTurler { get; set; }
    }
}
