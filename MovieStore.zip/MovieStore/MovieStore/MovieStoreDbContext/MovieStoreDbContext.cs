﻿using Microsoft.EntityFrameworkCore;
using MovieStore.Models;

namespace MovieStore.MovieStoreDbContext
{
    public class MovieStoreDbContext:DbContext
    {
        public DbSet<Film> Films { get; set; }
        public DbSet<Yonetmen> Yonetmenler { get; set; }
        public DbSet<Oyuncu> Oyuncular { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Siparis> Siparisler { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Veritabanı bağlantı dizesini buraya ekleyin
            optionsBuilder.UseSqlServer("Server=DESKTOP-PSI1QEU;Database=MovieStoreDb;Trusted_Connection=True;");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Film>()
                .Property(f => f.FilmAdi)
                .HasMaxLength(100)
                .IsRequired();
            modelBuilder.Entity<Yonetmen>()
                .Property(y => y.Isim)
                .HasMaxLength(50)
                .IsRequired();

            modelBuilder.Entity<Film>()
                .HasOne(f => f.Yonetmen)
                .WithMany(y => y.YonetilenFilmler)
                .HasForeignKey(f => f.FilmAdi)
                .OnDelete(DeleteBehavior.Restrict); 
        }
    }

}
