﻿using AutoMapper;
using Moq;
using MovieStore.DTO_s;
using MovieStore.Models;
using MovieStore.Services;
using System.ComponentModel.DataAnnotations;
using Xunit;

namespace MovieStore.UnitTest
{
    public class MovieStoreServiceTests
    {
        [Fact]
        public void AddFilm_ShouldAddFilm_WhenValidDTOProvided()
        {
            // Arrange
            var filmDTO = new FilmDTO
            {
                FilmAdi = "Example Film",
                FilmYili = 2022,
                FilmTuru = "Action",
                // Diğer özellikleri de buraya ekleyin
            };

            var mockDbContext = new Mock<MovieStoreDbContext>();
            var mockMapper = new Mock<IMapper>();
            var mockLogger = new Mock<ILogger<MovieStoreService>>();
            var movieStoreService = new MovieStoreService(mockDbContext.Object, mockMapper.Object, mockLogger.Object);

            // Act
            var result = movieStoreService.AddFilm(filmDTO);

            // Assert
            Assert.NotNull(result);
            // Diğer asertasyonları buraya ekleyin
        }

        [Fact]
        public void AddFilm_ShouldThrowValidationException_WhenInvalidDTOProvided()
        {
            // Arrange
            var invalidFilmDTO = new FilmDTO(); // Geçersiz DTO

            var mockDbContext = new Mock<MovieStoreDbContext>();
            var mockMapper = new Mock<IMapper>();
            var mockLogger = new Mock<ILogger<MovieStoreService>>();
            var movieStoreService = new MovieStoreService(mockDbContext.Object, mockMapper.Object, mockLogger.Object);

            // Act & Assert
            Assert.Throws<ValidationException>(() => movieStoreService.AddFilm(invalidFilmDTO));
        }

        [Fact]
        public void GetFilmById_ShouldReturnFilm_WhenValidIdProvided()
        {
            // Arrange
            var filmId = 1;
            var mockFilm = new Film { Id = filmId, FilmAdi = "Example Film" }; // Mock veritabanı kaydı

            var mockDbContext = new Mock<MovieStoreDbContext>();
            mockDbContext.Setup(db => db.Films.Find(It.IsAny<int>())).Returns(mockFilm);

            var mockMapper = new Mock<IMapper>();
            var mockLogger = new Mock<ILogger<MovieStoreService>>();
            var movieStoreService = new MovieStoreService(mockDbContext.Object, mockMapper.Object, mockLogger.Object);

            // Act
            var result = movieStoreService.GetFilmById(filmId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(filmId, result.Id);
            // Diğer asertasyonları buraya ekleyin
        }

        [Fact]
        public void GetFilmById_ShouldReturnNull_WhenInvalidIdProvided()
        {
            // Arrange
            var invalidFilmId = 999; // Var olmayan bir Id

            var mockDbContext = new Mock<MovieStoreDbContext>();
            var mockMapper = new Mock<IMapper>();
            var mockLogger = new Mock<ILogger<MovieStoreService>>();
            var movieStoreService = new MovieStoreService(mockDbContext.Object, mockMapper.Object, mockLogger.Object);

            // Act
            var result = movieStoreService.GetFilmById(invalidFilmId);

            // Assert
            Assert.Null(result);
        }

    }
}
