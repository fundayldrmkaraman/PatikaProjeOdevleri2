﻿using AutoMapper;
using MovieStore.DTO_s;
using MovieStore.Models;

namespace MovieStore.AutoMapper
{
    public class AutoMapperProfile:Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Film, FilmDTO>();
            CreateMap<Yonetmen, YonetmenDTO>();
            CreateMap<Oyuncu, OyuncuDTO>();
            CreateMap<Customer, CustomerDTO>();
            CreateMap<Siparis, SiparisDTO>();
        }
    }
}
