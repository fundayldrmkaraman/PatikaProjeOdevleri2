﻿namespace MovieStore.DTO_s
{
    public class SiparisDTO
    {
        public int Id { get; set; }
        public CustomerDTO Musteri { get; set; }
        public FilmDTO SatinAlinanFilm { get; set; }
        public decimal Fiyat { get; set; }
        public DateTime SatinAlmaTarihi { get; set; }
    }
}
