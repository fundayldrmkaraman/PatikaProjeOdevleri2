﻿namespace MovieStore.DTO_s
{
    public class YonetmenDTO
    {
        public int Id { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public List<FilmDTO> YonetilenFilmler { get; set; }
        public string Kategori { get; set; }
    }
}
