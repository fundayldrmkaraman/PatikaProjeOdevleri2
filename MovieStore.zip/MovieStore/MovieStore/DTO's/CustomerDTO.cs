﻿namespace MovieStore.DTO_s
{
    public class CustomerDTO
    {
        public int Id { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public List<FilmDTO> SatinAldigiFilmler { get; set; }
        public List<string> FavoriTurler { get; set; }
    }
}
