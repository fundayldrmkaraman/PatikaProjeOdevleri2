﻿namespace MovieStore.DTO_s
{
    public class OyuncuDTO
    {
        public int Id { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public List<FilmDTO> OynadigiFilmler { get; set; }
        public string Kategori { get; set; }
    }
}
