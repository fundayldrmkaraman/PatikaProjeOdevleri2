﻿namespace MovieStore.DTO_s
{
    public class FilmDTO
    {
        public int Id { get; set; }
        public string FilmAdi { get; set; }
        public int FilmYili { get; set; }
        public string FilmTuru { get; set; }
        public YonetmenDTO Yonetmen { get; set; }
        public List<OyuncuDTO> Oyuncular { get; set; }
        public decimal Fiyat { get; set; }
        public string Kategori { get; set; }
    }
}
