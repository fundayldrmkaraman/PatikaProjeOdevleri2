﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieStore.DTO_s;
using MovieStore.Services;
using System.ComponentModel.DataAnnotations;

namespace MovieStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieStoreController : ControllerBase
    {
        private readonly ILogger<MovieStoreController> _logger;
        private readonly IMovieStoreService _movieStoreService;

        public MovieStoreController(ILogger<MovieStoreController> logger, IMovieStoreService movieStoreService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _movieStoreService = movieStoreService ?? throw new ArgumentNullException(nameof(movieStoreService));
        }

        [HttpPost("AddFilm")]
        public IActionResult AddFilm([FromBody] FilmDTO filmDTO)
        {
            try
            {
                var addedFilm = _movieStoreService.AddFilm(filmDTO);
                return CreatedAtAction(nameof(GetFilm), new { id = addedFilm.Id }, addedFilm);
            }
            catch (ValidationException ex)
            {
                _logger.LogError($"Film eklenirken hata oluştu: {ex.Message}");
                return BadRequest(new { Error = "Geçersiz istek. Hata detayları için günlükleri kontrol edin." });
            }
            catch (Exception ex)
            {
                _logger.LogError($"Film eklenirken genel hata oluştu: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
        }

        [HttpGet("GetFilm/{id}")]
        public IActionResult GetFilm(int id)
        {
            try
            {
                var film = _movieStoreService.GetFilmById(id);

                if (film == null)
                    return NotFound();

                return Ok(film);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Film getirilirken hata oluştu: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
        }

    }
}
