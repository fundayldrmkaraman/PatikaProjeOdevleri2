﻿using MovieStore.DTO_s;
using System.ComponentModel.DataAnnotations;

namespace MovieStore.Validation
{
    public class SiparisValidation
    {
        public static ValidationResult ValidateSiparis(SiparisDTO siparisDTO)
        {
            var validationResult = new ValidationResult();

            if (siparisDTO.Musteri == null || siparisDTO.Musteri.Id <= 0)
                validationResult.Errors.Add("Musteri", "Geçerli bir müşteri seçilmelidir.");

            if (siparisDTO.SatinAlinanFilm == null || siparisDTO.SatinAlinanFilm.Id <= 0)
                validationResult.Errors.Add("SatinAlinanFilm", "Geçerli bir film seçilmelidir.");

            if (siparisDTO.Fiyat <= 0)
                validationResult.Errors.Add("Fiyat", "Geçerli bir fiyat belirtilmelidir.");

            return validationResult;
        }
    }
}
