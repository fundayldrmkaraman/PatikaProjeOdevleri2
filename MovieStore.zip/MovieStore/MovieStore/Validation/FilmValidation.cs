﻿using MovieStore.DTO_s;
using System.ComponentModel.DataAnnotations;

namespace MovieStore.Validation
{
    public class FilmValidation
    {
        public static ValidationResult ValidateFilm(FilmDTO filmDTO)
        {
            var validationResult = new ValidationResult();

            if (string.IsNullOrEmpty(filmDTO.FilmAdi))
                validationResult.Errors.Add("FilmAdi", "Film adı boş olamaz.");

            if (filmDTO.FilmYili <= 0)
                validationResult.Errors.Add("FilmYili", "Film yılı geçersiz.");

            return validationResult;
        }
    }
}
