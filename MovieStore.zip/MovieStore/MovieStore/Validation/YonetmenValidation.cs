﻿using MovieStore.DTO_s;
using System.ComponentModel.DataAnnotations;

namespace MovieStore.Validation
{
    public class YonetmenValidation
    {
        public static ValidationResult ValidateYonetmen(YonetmenDTO yonetmenDTO)
        {
            var validationResult = new ValidationResult();

            if (string.IsNullOrEmpty(yonetmenDTO.Isim))
                validationResult.Errors.Add("Isim", "Yönetmen ismi boş olamaz.");

            return validationResult;
        }
}
