﻿using MovieStore.DTO_s;
using System.ComponentModel.DataAnnotations;

namespace MovieStore.Validation
{
    public class CustomerValidation
    {
        public static ValidationResult ValidateCustomer(CustomerDTO customerDTO)
        {
            var validationResult = new ValidationResult();

            if (string.IsNullOrEmpty(customerDTO.Isim))
                validationResult.Errors.Add("Isim", "Müşteri ismi boş olamaz.");

            return validationResult;
        }
    }
}
