﻿using MovieStore.DTO_s;
using System.ComponentModel.DataAnnotations;

namespace MovieStore.Validation
{
    public class OyuncuValidation
    {
        public static ValidationResult ValidateOyuncu(OyuncuDTO oyuncuDTO)
        {
            var validationResult = new ValidationResult();

            if (string.IsNullOrEmpty(oyuncuDTO.Isim))
                validationResult.Errors.Add("Isim", "Oyuncu ismi boş olamaz.");

            return validationResult;
        }
    }
}
